var ContactForm = React.createClass({ 
  displayName: "ContactForm",

  getInitialState: function(){
    return { first_name: '', last_name: '', email: '', message:'' }
  },
  //called on submit clicked
  handleSubmit: function(event){
    event.preventDefault();
    $.ajax({
      context: this, //pass the ContactForm instance
      type: 'POST',
      url: '/contact',
      data: {
        contact:{ 
          first_name: this.state.first_name, 
          last_name: this.state.last_name, 
          email: this.state.email, 
          message: this.state.message 
      }}
    })
    .done(function(data) {
      //reset the state
      this.clearForm()
    })
    .fail(function(error) {
      this.setState({
        errors: error.responseText
      });
    });
  },
  handleChangeFirstName(event) { //create state attribute with name "first_name"
    this.setState({first_name: event.target.value});
  },
  handleChangeLastName(event) { 
    this.setState({last_name: event.target.value});
  },
  handleChangeEmail(event) {
    this.setState({email: event.target.value});
  },
  handleChangeMessage(event) {
    this.setState({message: event.target.value});
  },
  clearForm: function() {
    this.setState({
      first_name: "",
      last_name: "",
      email: "",
      message: "",
      errors: ""
    });
  },
  render: function(){
    return (
      <div className="container">
        <div className="col-sm-12">
          <form onSubmit={this.handleSubmit}>
            <div className="actions">
              <input type="text" placeholder="First Name(Required)" value={this.state.first_name} 
                onChange={this.handleChangeFirstName} />
              <input type="text" placeholder="Last Name(Required)" value={this.state.last_name} 
                onChange={this.handleChangeLastName} />
              <input type="text" placeholder="Email(Required)" value={this.state.email} 
                onChange={this.handleChangeEmail} />
              <br/>
              <textarea type="text" placeholder="Message(Required)" value={this.state.message} 
                onChange={this.handleChangeMessage} />
              <br/>
              <button className="btn btn-primary">Submit</button>
            </div>
          </form>
        </div>
        {this.state.errors ? <p>Errors: <br/> {this.state.errors}</p> : ""}
      </div>
    )
  }
})
