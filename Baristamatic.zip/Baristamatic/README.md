# Baristamatic
Code challenge to create a simulator of an automatic coffee dispensing machine. The machine maintains an inventory of drink ingredients, and is able to dispense a fixed set of possible drinks by combining these ingredients in different amounts. The cost of a drink is computed as the total cost of its component ingredients.

# How to run this program: 
In the command line, type ruby runner.rb
You will be shown the inventory and the menu before each operation. Menu items that are not available (due to lack of ingredients) will display "false".

# Commands:
Drinks are ordered based on their number on the menu.
"R" or "r": restocks inventory
"Q" or "q": quits program



