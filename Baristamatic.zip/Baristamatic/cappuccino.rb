require_relative 'drink'

class Cappuccino < Drink
	
	def initialize
		super(4, "Cappuccino", {"Espresso" => 2, "Steamed Milk" => 1, "Foamed Milk" => 1})
	end

	def get_instance
		return Cappuccino.new
	end
end
