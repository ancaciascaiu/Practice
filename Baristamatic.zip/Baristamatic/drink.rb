
class Drink
	
	attr_reader :order_number, :name, :recipe
	attr_accessor :available
	def initialize(order_number, name, recipe)
		@order_number = order_number
		@name = name
		@recipe = recipe
		@available = true
	end
end