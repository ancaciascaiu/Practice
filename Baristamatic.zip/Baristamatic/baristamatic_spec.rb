require_relative "machine"

describe Machine do
  let(:machine) {Machine.new}

  describe "inventory stocked at initialization" do
    it 'has an inventory variable' do
      initial_inventory = [
        {name:  "Coffee", price: 0.75, quantity: 10},
        {name: "Decaf Coffee", price: 0.75, quantity: 10},
        {name: "Sugar", price: 0.25, quantity: 10},
        {name: "Cream", price: 0.25, quantity: 10},
        {name: "Steamed Milk", price: 0.35, quantity: 10},
        {name: "Foamed Milk", price: 0.35, quantity: 10},
        {name: "Espresso", price: 1.10, quantity: 10},
        {name: "Cocoa", price: 0.90, quantity: 10},
        {name: "Whipped Cream", price: 1.00, quantity: 10} 
      ]
      expect(machine.inventory).to eq(initial_inventory)
    end
  end

  describe "Types of drinks loaded at initialization" do
    it "has drinks that are instances of the Coffee classes" do
      expect(machine.drinks[0]).to be_instance_of(CaffeAmericano)
      expect(machine.drinks[-1]).to be_instance_of(DecafCoffee)
    end
  end

  describe "print inventory successfully" do
    it "prints inventory items one by one" do
      expect(machine.display_inventory).to be_instance_of(Array)
    end

    it "prints all items of the inventory" do
      expect(machine.display_inventory.count).to eq(9)
    end
  end

  describe "print menu successfully" do
    it "prints menu items one by one" do
      expect(machine.display_menu).to be_instance_of(Array)
    end

    it "prints all items of the menu" do
      expect(machine.display_menu.count).to eq(6)
    end
  end
  
  describe "Can make a coffee if inventory permits" do
    it "When able to dispense a coffee successfully, takes out corresponding units from ingredients " do
      machine.make_drink(5)
      machine.inventory.each do |ingredient|
        if ingredient[:name] == "Coffee"
          expect(ingredient[:quantity]).to be(7)
        end
      end
    end

    it "Error is returned if an invalid selection is entered" do
      expect(machine.make_drink(9)).to eq("Invalid selection: 9")
    end
  end


  describe "Calculates drink costs accurately" do
    it "Returns drink cost as float" do
      expect(machine.price(Coffee.new).to_f).to be_instance_of(Float)
    end
  end

end
