require_relative 'machine'

loop do
	#restock inventory (10units/ ingredient)
	machine = Machine.new
	user_input = ""
	#loop until enough options in inventory
	while user_input.downcase != "q"
		# print inventory
		machine.display_inventory
		# print menu
		machine.display_menu
		# ask user for input
		user_input = gets.chomp
		# choices can only be: r, R, q, Q, 1-6
		# if choice was made, run and print user's choice
		# q quits the entire program:
		if user_input.downcase == "q"
			return
		#restock ("r") takes us to the outer loop:
		elsif user_input.downcase == "r"
			break
		elsif user_input.to_i.is_a? Integer
			machine.make_drink(user_input)
		else
			puts "Invalid selection: #{user_input}"
		end
		# if drink cannot be made, print "out of stock" = in machine
	end
end

