require_relative 'drink'

class CaffeLatte < Drink
	
	def initialize
		super(2, "Caffe Latte", {"Espresso" => 2, "Steamed Milk" => 1})
	end

	def get_instance
		return CaffeLatte.new
	end
end
