require_relative 'drink'

class CaffeAmericano < Drink
	
	def initialize
		super(1, "Caffe Americano", {"Espresso" => 3})
	end

	def get_instance
		return CaffeAmericano.new
	end
end
