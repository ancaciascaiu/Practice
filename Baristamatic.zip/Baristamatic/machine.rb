
require_relative 'coffee'
require_relative 'caffe_americano'
require_relative 'caffe_latte'
require_relative 'caffe_mocha'
require_relative 'cappuccino'
require_relative 'decaf_coffee'
#Machine is initialized with an inventory
class Machine
	attr_accessor :inventory, :drinks
	def initialize
		@inventory = [
	      {name:  "Coffee", price: 0.75, quantity: 10},
	      {name: "Decaf Coffee", price: 0.75, quantity: 10},
	      {name: "Sugar", price: 0.25, quantity: 10},
	      {name: "Cream", price: 0.25, quantity: 10},
	      {name: "Steamed Milk", price: 0.35, quantity: 10},
	      {name: "Foamed Milk", price: 0.35, quantity: 10},
	      {name: "Espresso", price: 1.10, quantity: 10},
	      {name: "Cocoa", price: 0.90, quantity: 10},
	      {name: "Whipped Cream", price: 1.00, quantity: 10} 
	    ]
		
		@drinks = [ CaffeAmericano.new, CaffeLatte.new, CaffeMocha.new, Cappuccino.new, Coffee.new, DecafCoffee.new ]   
	end

	def display_inventory
		puts "Inventory:\n" 
		@inventory.each do |item|
			puts "#{item[:name]},#{item[:quantity]}"
		end
	end

	def display_menu
		puts "Menu:\n"
		@drinks.each do |drink|
			puts "#{drink.order_number},#{drink.name},$#{price(drink)},#{drink.available}"
		end
	end

	def make_drink(drink_id)
		@drinks.each do |item|
			if item.order_number == drink_id.to_i
				new_coffee = item.get_instance
				if ingredients_available?(new_coffee.recipe)
					#for the menu to display
					item.available = true
					puts "Dispensing: #{new_coffee.name}"
					update_inventory(new_coffee)
					true
				else
					#for the menu to display	
					item.available = false
					puts "Out of stock: #{new_coffee.name}"
					false
				end
				#item found return now
				return
			end
		end
		puts "Invalid selection: #{drink_id}"
		"Invalid selection: #{drink_id}"
	end

	
	def price(drink)
		#price(Coffee.new)
		price = 0
		drink.recipe.each do |ingredient, units|
			@inventory.each do |item|
				if ingredient == item[:name]
					price += item[:price] * units
				end
			end
		end
		sprintf('%.2f', price)
	end

	def update_inventory(coffee)
		coffee.recipe.each do |ingredient, units|
			@inventory.each do |item|
				if ingredient == item[:name]
					item[:quantity] -= units
				end
			end
		end
	end

	def ingredients_available?(recipe)
		recipe.each do |ingredient, units|
			@inventory.each do |item|
				if ingredient == item[:name]
					if item[:quantity] < units
						return false

					end
				end
			end
		end
		true
	end

end




