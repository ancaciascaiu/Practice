require_relative 'drink'

class Coffee < Drink
	
	def initialize
		super(5, "Coffee", {"Coffee" => 3, "Sugar"=> 1, "Cream"=> 1})
	end

	def get_instance
		return Coffee.new
	end
end
