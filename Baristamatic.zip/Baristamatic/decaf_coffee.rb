require_relative 'drink'

class DecafCoffee < Drink
	
	def initialize
		super(6, "Decaf Coffee", {"Decaf Coffee" => 3, "Sugar" => 1, "Cream" => 1})
	end

	def get_instance
		return DecafCoffee.new
	end
end
