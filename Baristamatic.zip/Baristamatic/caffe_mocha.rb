require_relative 'drink'

class CaffeMocha < Drink
	
	def initialize
		super(3, "Caffe Mocha", {"Espresso" => 1, "Cocoa" => 1, "Steamed Milk" => 1, "Whipped Cream" => 1})
	end

	def get_instance
		return CaffeMocha.new
	end
end
